import java.awt.Graphics;

public interface Actor {
    public void paint(Graphics g);
}
